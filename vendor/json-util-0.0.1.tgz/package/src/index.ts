enum EMapKeyType {
    String = 0,
    Number = 1,
}

enum EConvertType {
    None = 0,
    FirstLayer,
    All,
}

const USE_JSON_CONVERTER_V2 = true;

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const matchNumberReg = /^[0-9]+n$/;
function convertFromJsonObjectImpV1(
    obj: any,
    reviver?: (key: string, value: any) => any,
    checkMeta: boolean = true,
    returnNewObj: boolean = true
): any {
    const t = typeof obj;
    if (obj !== null && obj !== undefined && t === "object") {
        if (Array.isArray(obj)) {
            let ret = returnNewObj ? new Array(obj.length) : obj;
            const count = obj.length;
            for (let i = 0; i < count; i++) {
                ret[i] = convertFromJsonObjectImpV1(obj[i], reviver, checkMeta);
            }
            return ret;
        }

        if (checkMeta && obj.__m !== undefined) {
            const ret = new Map();
            let isNumberKey = obj.__m === EMapKeyType.Number;
            for (const k in obj) {
                if (k === "__m") continue;
                ret.set(
                    isNumberKey && !isNaN(Number(k)) ? Number(k) : k,
                    reviver
                        ? reviver(k, convertFromJsonObject(obj[k], reviver, checkMeta))
                        : convertFromJsonObject(obj[k], reviver, checkMeta)
                );
            }
            return ret;
        } else {
            // eslint-disable-next-line guard-for-in
            let ret = returnNewObj ? ({} as any) : obj;
            for (const k in obj) {
                ret[k] = reviver
                    ? reviver(k, convertFromJsonObject(obj[k], reviver, checkMeta))
                    : convertFromJsonObject(obj[k], reviver, checkMeta);
            }
            return ret;
        }
    } else if (t === "string" && matchNumberReg.test(obj)) {
        return BigInt(obj.substring(0, obj.length - 1)); // 将字符串转换为 bigint
    }
    return obj;
}

type ReviverFunc = (key: string | number, value: any, checkMeta: boolean, returnNewObj: boolean) => any;

function generateReviverFunc(convertType: EConvertType, reviver?: (key: string, value: any) => any): ReviverFunc {
    if (reviver) {
        switch (convertType) {
            case EConvertType.None:
            case EConvertType.FirstLayer:
                return (key: string | number, value: any) => {
                    if (typeof key === "string") return reviver(key, value);
                    else return value;
                };
            case EConvertType.All: {
                const func = (key: string | number, v: any, checkMeta: boolean, returnNewObj: boolean) => {
                    let value = convertFromJsonObjectImpV2(v, func, checkMeta, returnNewObj);
                    if (typeof key === "string") return reviver(key, value);
                    else return value;
                };
                return func;
            }
        }
    } else {
        switch (convertType) {
            case EConvertType.None:
            case EConvertType.FirstLayer:
                return (key: string | number, value: any) => value;
            case EConvertType.All: {
                const func = (_key: string | number, value: any, checkMeta: boolean, returnNewObj: boolean): any =>
                    convertFromJsonObjectImpV2(value, func, checkMeta, returnNewObj);
                return func;
            }
        }
    }
}

export function convertFromJsonObject(obj: any, reviver?: (key: string, value: any) => any, checkMeta: boolean = true) {
    if (USE_JSON_CONVERTER_V2) {
        const reviverFunc = generateReviverFunc(EConvertType.All, reviver);
        return convertFromJsonObjectImpV2(obj, reviverFunc, checkMeta, true);
    } else {
        return convertFromJsonObjectImpV1(obj, reviver, checkMeta, true);
    }
}

function convertFromJsonObjectImpV2(obj: any, reviver: ReviverFunc, checkMeta: boolean, returnNewObj: boolean): any {
    const t = typeof obj;
    if (obj !== null && t === "object") {
        if (Array.isArray(obj)) {
            let ret = returnNewObj ? new Array(obj.length) : obj;
            const count = obj.length;
            for (let i = 0; i < count; ++i) {
                ret[i] = reviver(i, obj[i], checkMeta, returnNewObj);
            }
            return ret;
        }

        if (checkMeta && obj.__m !== undefined) {
            const ret = new Map();
            let isNumberKey = obj.__m === EMapKeyType.Number;
            delete obj.__m;

            for (const k in obj) {
                ret.set(isNumberKey && !isNaN(Number(k)) ? Number(k) : k, reviver(k, obj[k], checkMeta, returnNewObj));
            }
            return ret;
        } else {
            // eslint-disable-next-line guard-for-in
            let ret = returnNewObj ? ({} as any) : obj;
            for (const k in obj) {
                ret[k] = reviver(k, obj[k], checkMeta, returnNewObj);
            }
            return ret;
        }
    } else if (t === "string" && matchNumberReg.test(obj)) {
        return BigInt(obj.substring(0, obj.length - 1)); // 将字符串转换为 bigint
    }
    return obj;
}

const replaceReg = /:\s*([\d]{15,})/g;
export function parse<T = any>(jsonString: string, reviver?: (key: string, value: any) => any, checkMeta = true): T {
    let formattedJsonString = jsonString.replace(replaceReg, ': "$1n"');

    // 解析 JSON 字符串
    const originalJsonObj = JSON.parse(formattedJsonString);

    if (USE_JSON_CONVERTER_V2) {
        let convertType = formattedJsonString === jsonString ? EConvertType.None : EConvertType.All;

        if (convertType === EConvertType.None) {
            let firstMetaIndex = formattedJsonString.lastIndexOf('"__m"');
            if (firstMetaIndex >= 0) {
                convertType = EConvertType.FirstLayer;
                if (
                    originalJsonObj.__m === undefined ||
                    formattedJsonString.lastIndexOf('"__m"', firstMetaIndex - 1) >= 0
                ) {
                    // 多个 __m 时，需要全部转换
                    convertType = EConvertType.All;
                }
            }
        }

        if (convertType === EConvertType.None && !reviver) return originalJsonObj;

        const reviverFunc = generateReviverFunc(convertType, reviver);
        return convertFromJsonObjectImpV2(originalJsonObj, reviverFunc, checkMeta, false);
    } else {
        return convertFromJsonObjectImpV1(originalJsonObj, reviver, checkMeta, false);
    }
}

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// eslint-disable-next-line complexity
export function convertToJsonObject(obj: any, exportMeta = true, removeNullOrUndefinedValue = true) {
    return convertToJsonObjectImp(obj, exportMeta, removeNullOrUndefinedValue, new Set());
}

function convertToJsonObjectImp(obj: any, exportMeta: boolean, removeNullOrUndefinedValue: boolean, objs: Set<any>) {
    if (obj === null || obj === undefined) return obj;
    else if (typeof obj === "bigint") return obj.toString() + "n";
    else if (typeof obj !== "object") return obj;

    let ret: any;
    let temp: any;
    if (objs.has(obj)) throw new Error("Circular structure is not supported");
    objs.add(obj);

    if (obj instanceof Map) {
        if (exportMeta) {
            ret = {} as any;
            let keyType = EMapKeyType.String;
            for (let [k, v] of obj) {
                if (typeof k === "number") keyType = EMapKeyType.Number;
                temp = convertToJsonObjectImp(v, exportMeta, removeNullOrUndefinedValue, objs);
                if ((temp === null || temp === undefined) && removeNullOrUndefinedValue) continue;
                ret[k] = temp;
            }
            ret.__m = keyType;
        } else {
            ret = {};
            for (let [k, v] of obj) {
                temp = convertToJsonObjectImp(v, exportMeta, removeNullOrUndefinedValue, objs);
                if ((temp === null || temp === undefined) && removeNullOrUndefinedValue) continue;
                ret[k] = temp;
            }
        }
    } else if (Array.isArray(obj)) {
        ret = new Array();
        for (let i = 0; i < obj.length; ++i) {
            temp = convertToJsonObjectImp(obj[i], exportMeta, removeNullOrUndefinedValue, objs);
            if ((temp === null || temp === undefined) && removeNullOrUndefinedValue) continue;
            ret.push(temp);
        }
    } else {
        ret = {} as any;
        for (let [key, value] of Object.entries(obj)) {
            temp = convertToJsonObjectImp(value, exportMeta, removeNullOrUndefinedValue, objs);
            if ((temp === null || temp === undefined) && removeNullOrUndefinedValue) continue;
            ret[key] = temp;
        }
    }

    objs.delete(obj);
    return ret;
}

export function stringify(obj: any, exportMeta = true, removeNullOrUndefinedValue = true) {
    let ret = convertToJsonObject(obj, exportMeta, removeNullOrUndefinedValue);
    return JSON.stringify(ret);
}

export function safeStringify(obj: any, exportMeta = true, removeNullOrUndefinedValue = true) {
    try {
        let ret = convertToJsonObject(obj, exportMeta, removeNullOrUndefinedValue);
        return JSON.stringify(ret, null, 2);
    } catch {
        return "Error: Circular structure is not supported";
    }
}
